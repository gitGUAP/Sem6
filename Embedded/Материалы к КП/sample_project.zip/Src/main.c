/**
 * Simple example that demonstrate basic microcontroller configuration.
 *
 * The program sets CPU clock to 48 MHz and configure board leds.
 */

// include register definition from HAL library
#include "stm32f3xx.h"

/**
 * Helper function to modify register bits.
 */
void modifyRegister(volatile uint32_t* regAddr, uint32_t mask, uint32_t value)
{
    uint32_t tmp;
    tmp = *regAddr;
    tmp &= ~mask;
    tmp |= value & mask;
    *regAddr = tmp;
}

/**
 * Helper function that waits till specified bits are set to expected value.
 */
void waitRegisterValue(volatile uint32_t* regAddr, uint32_t mask, uint32_t expectedValue)
{
    while ((*regAddr & mask) != expectedValue)
        ;
}

/**
 * Helper function for delay implementation.
 *
 * @note the delay depends on complicator optimization and CPU frequency.
 */
void delay(uint32_t num_ops)
{
    volatile uint32_t count = 0;
    while (count < num_ops) {
        count++;
    }
}

/**
 * Function to configure CPU frequency (SYSCLOCK).
 *
 * After configurration CPU frequency will be changed from 8 MHz to 48 MHz.
 */
void configClock()
{
    // HSI is enabled by default and used as SYSCLOCK.
    // So currect SYSCLOCK frequency is 8 MHz

    // 1. Configure PLL (phase-locked loop) to increase frequncy
    // 1.1 Set CFGR bits 15-16 to 0b00 use HSI as source clock for PLL
    //     note: f_PLL_input = freq_HSI / 2 = 4 MHz
    modifyRegister(&(RCC->CFGR), 0x00018000, 0x00000000);
    // 1.2 Set CFGR bits 18-21 to 0b1010 for PLL  multiplication factor 12
    //     note: f_PLL_output = f_PLL_input * 12 = 4 * 12 = 48 MHz
    modifyRegister(&(RCC->CFGR), 0x003C0000, 0x00280000);
    // 1.3 Enable PLL (set CR bit 24 to 1).
    modifyRegister(&(RCC->CR), 0x01000000, 0x01000000);
    // 1.4 Wait till PLL is enable (check CR bit 25).
    waitRegisterValue(&(RCC->CR), 0x02000000, 0x02000000);
    // 2. Configure flash latency for CPU frequency 48 MHz
    modifyRegister(&(FLASH->ACR), 0x00000007, 0x00000001);
    // 3. Switch SYSCLK from HSI to PLL
    // 3.1 Set PLL as SYSCLK source (set CFGR bits 0-1 to 0b10).
    modifyRegister(&(RCC->CFGR), 0x00000003, 0x00000002);
    // 3.2 Wait end of SYSCLK source configuration (check that CFGR bits 2-3 is 0b10).
    waitRegisterValue(&(RCC->CFGR), 0x0000000C, 0x00000008);

    // update global variable with system frequency
    // note: we can use it check that set configure frequency correctly (the SystemCoreClock should be set to 0X02DC6C00)
    SystemCoreClockUpdate();
}

/**
 * Configure LED pins.
 */
void configLEDS()
{
    // 1. Enable clock of the GPIOE
    modifyRegister(&(RCC->AHBENR), RCC_AHBENR_GPIOEEN, RCC_AHBENR_GPIOEEN);
    // 2. Set high speed
    modifyRegister(&(GPIOE->OSPEEDR), 0xFFFF0000, 0xFFFF0000);
    // 3. Disable pull up/down registers
    modifyRegister(&(GPIOE->PUPDR), 0xFFFF0000, 0x00000000);
    // 4. Set pull/push mode
    modifyRegister(&(GPIOE->OTYPER), 0x0000FF00, 0x00000000);
    // 5. Set general output mode
    modifyRegister(&(GPIOE->MODER), 0xFFFF0000, 0x55550000);
}

int main(void)
{
    // configure CPU frequency to 48 MHz
    configClock();
    // configure leds
    configLEDS();

    // simple led blinking
    uint8_t ledMask = 0x01;
    while (1) {
        // update led mask
        if (ledMask & 0x80) {
            ledMask = ledMask ^ 0x01;
        }
        ledMask = (ledMask << 1) + 0x01;
        // show animation
        GPIOE->ODR = (GPIOE->ODR & 0xFFFF00FF) | (ledMask << 8);
        delay(1000000);
    }
}
